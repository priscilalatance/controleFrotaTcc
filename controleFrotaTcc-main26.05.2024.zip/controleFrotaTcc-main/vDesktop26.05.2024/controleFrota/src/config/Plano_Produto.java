package config;

/**
 *
 * @author Priscila
 */
public class Plano_Produto {
    private Integer idPlano;
    private Integer idCodigo;

    public Integer getIdPlano() {
        return idPlano;
    }

    public void setIdPlano(Integer idPlano) {
        this.idPlano = idPlano;
    }

    public Integer getIdCodigo() {
        return idCodigo;
    }

    public void setIdCodigo(Integer idCodigo) {
        this.idCodigo = idCodigo;
    }
    
    
}
