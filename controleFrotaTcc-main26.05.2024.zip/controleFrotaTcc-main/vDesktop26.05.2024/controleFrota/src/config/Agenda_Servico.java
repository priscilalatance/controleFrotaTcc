package config;

/**
 *
 * @author Priscila
 */
public class Agenda_Servico {
    
    private Integer idAgendaServico;
    private Integer idOrdem;
    private Integer idAgenda;

    public Integer getIdOrdem() {
        return idOrdem;
    }

    public void setIdOrdem(Integer idOrdem) {
        this.idOrdem = idOrdem;
    }

    public Integer getIdAgenda() {
        return idAgenda;
    }

    public void setIdAgenda(Integer idAgenda) {
        this.idAgenda = idAgenda;
    }

    public Integer getIdAgendaServico() {
        return idAgendaServico;
    }

    public void setIdAgendaServico(Integer idAgendaServico) {
        this.idAgendaServico = idAgendaServico;
    }
    
}
